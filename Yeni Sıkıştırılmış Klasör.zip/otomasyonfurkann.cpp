#include <iomanip>
#include <cstring>
#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include <fstream>
#include <iostream>

using namespace std;

struct Elektrikci
{
    char ad[80];
    char soyad[80];
    char telefon_no[15];
    char usta_seviyesi;  
};

void ElektrikciEkle();
void ElektrikciListeleme();
void ElektrikciArama();
void ElektrikciSil();
void ElektrikciDuzenle();

int main()
{
    char anamenu;
    do
    {
        system("cls");

        cout << "|------Hosgeldiniz----------|" << endl;
        cout << "|      Secim Yapiniz        |" << endl;
        cout << "|   1- Elektrikci Ekleme    |" << endl;
        cout << "|   2- Elektrikci Listeleme |" << endl;
        cout << "|   3- Elektrikci Arama     |" << endl;
        cout << "|   4- Elektrikci Sil       |" << endl;
        cout << "|   5- Elektrikci Duzenle   |" << endl;
        cout << "|-------------------------- |" << endl;
        
        char secim;
        cin >> secim;

        switch (secim)
        {
            case '1':
            {
                ElektrikciEkle();
                break;
            }
            case '2':
            {
                ElektrikciListeleme();
                break;
            }
            case '3':
            {
                ElektrikciArama();
                break;
            }
            case '4':
            {
                ElektrikciSil();
                break;
            }
            case '5':
            {
                ElektrikciDuzenle();
                break;
            }
        }

        cout << "Anamenuye Donmek icin: a basin cikmak icin: c" << endl;
        anamenu = getche();

    } while (anamenu == 'a');

    return 0;
}

Elektrikci elektrikci;

void ElektrikciEkle()
{
    ofstream yaz("elektrikci.dat", ios::binary | ios::app);
    char secim;
    int adet = 0;

    do
    {
        cout << "Elektrikci Adi Giriniz" << endl;
        cin >> elektrikci.ad;
        cout << "Elektrikci Soyadi Giriniz" << endl;
        cin >> elektrikci.soyad;
        cout << "Elektrikci Telefon No Giriniz" << endl;
        cin >> elektrikci.telefon_no;
        cout << "Elektrikci Usta Seviyesi Giriniz (A/B/C)" << endl;
        elektrikci.usta_seviyesi = getche();
        cout << endl;
        
        yaz.write((char*)&elektrikci, sizeof(elektrikci));
        adet++;

        cout << "Baska Kayit Eklemek Istermisin (E/H)" << endl;
        secim = getche();
        cout << endl;
    } while (secim == 'e' || secim == 'E');

    cout << adet << " adet Elektrikci Ekledi.." << endl;

    yaz.close();
}

void ElektrikciListeleme()
{
    ifstream oku("elektrikci.dat", ios::binary | ios::app);

    oku.seekg(0, ios::end);
    int kayits = oku.tellg() / sizeof(elektrikci);
    cout << "Toplam Elektrikci Kayit Sayisi: " << kayits << endl;

    if (kayits > 0)
    {
        for (int i = 0; i < kayits; i++)
        {
            oku.seekg(i * sizeof(elektrikci));
            oku.read((char*)&elektrikci, sizeof(elektrikci));

            cout << i + 1 << ". Elektrikcinin Bilgileri" << endl;
            cout << "Elektrikci Adi: " << elektrikci.ad << endl;
            cout << "Elektrikci Soyadi: " << elektrikci.soyad << endl;
            cout << "Elektrikci Telefon No: " << elektrikci.telefon_no << endl;
            if (elektrikci.usta_seviyesi == 'A' || elektrikci.usta_seviyesi == 'a')
                cout << "Elektrikci Usta Seviyesi: A" << endl;
            else if (elektrikci.usta_seviyesi == 'B' || elektrikci.usta_seviyesi == 'b')
                cout << "Elektrikci Usta Seviyesi: B" << endl;
            else if (elektrikci.usta_seviyesi == 'C' || elektrikci.usta_seviyesi == 'c')
                cout << "Elektrikci Usta Seviyesi: C" << endl;
        }
    }
    else
        cout << "Kayit Bulunamadi..." << endl;

    oku.close();
}

void ElektrikciArama()
{
    ifstream oku("elektrikci.dat", ios::binary | ios::app);

    oku.seekg(0, ios::end);
    int kayits = oku.tellg() / sizeof(elektrikci);

    cout << "Aranan Elektrikci Telefon No Giriniz" << endl;
    char telefon_no[15];
    cin >> telefon_no;

    if (kayits > 0)
    {
        for (int i = 0; i < kayits; i++)
        {
            oku.seekg(i * sizeof(elektrikci));
            oku.read((char*)&elektrikci, sizeof(elektrikci));

            if (strcmp(elektrikci.telefon_no, telefon_no) == 0)
            {
                cout << "Bulunan Elektrikcinin Bilgileri" << endl;
                cout << "Elektrikci Adi: " << elektrikci.ad << endl;
                cout << "Elektrikci Soyadi: " << elektrikci.soyad << endl;
                cout << "Elektrikci Telefon No: " << elektrikci.telefon_no << endl;
                if (elektrikci.usta_seviyesi == 'A' || elektrikci.usta_seviyesi == 'a')
                    cout << "Elektrikci Usta Seviyesi: A" << endl;
                else if (elektrikci.usta_seviyesi == 'B' || elektrikci.usta_seviyesi == 'b')
                    cout << "Elektrikci Usta Seviyesi: B" << endl;
                else if (elektrikci.usta_seviyesi == 'C' || elektrikci.usta_seviyesi == 'c')
                    cout << "Elektrikci Usta Seviyesi: C" << endl;
            }
        }
    }
    else
        cout << "Kayit Bulunamadi..." << endl;

    oku.close();
}

void ElektrikciSil()
{
    char telefon_no[15];
    char secim = ' ';
    bool var = false;

    ifstream oku("elektrikci.dat", ios::binary | ios::app);

    oku.seekg(0, ios::end);
    int kayitsayisi = oku.tellg() / sizeof(elektrikci);

    cout << "Kaydini Sileceginiz Elektrikci Telefon No Giriniz: ";
    cin >> telefon_no;

    for (int i = 0; i < kayitsayisi; i++)
    {
        oku.seekg(i * sizeof(elektrikci));
        oku.read((char*)&elektrikci, sizeof(elektrikci));

        if (strcmp(elektrikci.telefon_no, telefon_no) == 0)
        {
            cout << endl;
            cout << "Elektrikcinin" << endl;
            cout << "Adi: " << elektrikci.ad << endl;
            cout << "Soyadi: " << elektrikci.soyad << endl;
            cout << "Telefon No: " << elektrikci.telefon_no << endl;

            cout << "\nSilmek Istediginiz Kayit Bu Mu? [E/H]: ";
            secim = getche();
            if (secim == 'e' || secim == 'E')
            {
                var = true;
            }
        }
    }
    oku.close();

    if (var)
    {
        remove("elektrikci.dat");
        cout << "\nKayit Silindi." << endl;
    }
    else
    {
        cout << "\nKayit Bulunamadi." << endl;
    }
}

void ElektrikciDuzenle()
{
    char telefon_no[15];
    char secim = ' ';
    bool var = false;

    ifstream oku("elektrikci.dat", ios::binary | ios::app);

    oku.seekg(0, ios::end);
    int kayitsayisi = oku.tellg() / sizeof(elektrikci);

    cout << "Kaydini Duzelteceginiz Elektrikci Telefon No Giriniz: ";
    cin >> telefon_no;

    for (int i = 0; i < kayitsayisi; i++)
    {
        oku.seekg(i * sizeof(elektrikci));
        oku.read((char*)&elektrikci, sizeof(elektrikci));

        if (strcmp(elektrikci.telefon_no, telefon_no) == 0)
        {
            cout << endl;
            cout << "Elektrikcinin" << endl;
            cout << "Adi: " << elektrikci.ad << endl;
            cout << "Soyadi: " << elektrikci.soyad << endl;
            cout << "Telefon No: " << elektrikci.telefon_no << endl;
            cout << "\nDuzeltmek Istediginiz Kayit Bu Mu? [E/H]: ";
            secim = getche();
            if (secim == 'e' || secim == 'E')
            {
                var = true;
                ofstream dosya("Yedek.dat", ios::app | ios::binary);
                cout << "\nElektrikci Ad Giriniz" << endl;
                cin >> elektrikci.ad;
                cout << "Elektrikci Soyad Giriniz" << endl;
                cin >> elektrikci.soyad;
                cout << "Elektrikci Telefon No Giriniz" << endl;
                cin >> elektrikci.telefon_no;
                cout << "Elektrikci Usta Seviyesi Giriniz (A/B/C)" << endl;
                elektrikci.usta_seviyesi = getche();
                cout << endl;

                dosya.write((char*)&elektrikci, sizeof(elektrikci));
                dosya.close();
            }
        }
    }
    oku.close();

    if (var)
    {
        remove("elektrikci.dat");
        rename("Yedek.dat", "elektrikci.dat");
        cout << "\nKayit Duzeltildi." << endl;
    }
    else
    {
        remove("Yedek.dat");
        cout << "\nKayit Bulunamadi." << endl;
    }
}

